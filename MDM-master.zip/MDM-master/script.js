

// document.querySelector('#details').addEventListener('click', function(){
//     location.href = "../Products_details/products_details.html";
// });


    
// document.querySelector('#details').addEventListener('click', function(){
   
//     document.querySelectorAll('#details');

//     for (var i = 0; i < details.length; i++){
//         location.href = "../Products_details/products_details.html";
//     }
    
// });

// document.querySelectorAll('#details');

// details.forEach(details => {
//     location.href = "../Products_details/products_details.html";
// });

document.querySelectorAll('#details').forEach(item => {item.addEventListener('click', event => {
    location.href = "../Products_details/products_details.html";
    demol.textContent = "welcome";
})});

var demol = document.getElementById('demo');


// document.querySelector('#shirt-cart-button').addEventListener('click', function(){
//     document.querySelector('.whole-nav').style.opacity="0.2";

// });


// document.querySelector('#home').addEventListener('click', function(){
//         document.querySelector('.whole-nav').style.opacity="1";
    
// });

