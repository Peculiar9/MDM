# MDM
An Ecommerce Webapplication
The first commit was the index page and some unecessary necessity like bootstrap files. 
Next was the admin page and the user and admin Login

